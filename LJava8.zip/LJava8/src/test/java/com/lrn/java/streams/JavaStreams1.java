package com.lrn.java.streams;

import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.swing.plaf.synth.SynthScrollBarUI;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.contains;
import static org.hamcrest.beans.HasPropertyWithValue.hasProperty;
import static org.junit.Assert.assertEquals;

import org.junit.After;
import org.junit.Test;

import com.lrn.java.commons.Employee;
import com.lrn.java.commons.EmployeeRepository;

public class JavaStreams1 {

	private static Employee[] arrayOfEmps = {
		    new Employee(1, "Jeff Bezos", 100000.0), 
		    new Employee(2, "Bill Gates", 200000.0), 
		    new Employee(3, "Mark Zuckerberg", 300000.0)
	};
	
	//We can also obtain a stream from an existing list:
	private static List<Employee> empList = Arrays.asList(arrayOfEmps);
	
	@Test
	public void test() {		
		//Let’s first obtain a stream from an existing array:	
		Stream.of(arrayOfEmps);
	}
	
	@Test
	public void test1() {
		//We can also obtain a stream from an existing list:
		empList.stream();
	}
	
	@Test
	public void test2(){
		//Note that Java 8 added a new stream() method to the Collection interface.
		//And we can create a stream from individual objects using Stream.of():
		Stream.of(arrayOfEmps[0], arrayOfEmps[1], arrayOfEmps[2]);	
	}
	
	@Test
	public void test3() {
		//Or simply using Stream.builder():
		Stream.Builder<Employee> empStreamBuilder = Stream.builder();
		empStreamBuilder.accept(arrayOfEmps[0]);
		empStreamBuilder.accept(arrayOfEmps[1]);
		empStreamBuilder.accept(arrayOfEmps[2]);

		Stream<Employee> empStream = empStreamBuilder.build();

		//There are also other ways to obtain a stream, some of which we will see in sections below.		
	}
	
		
//=====================================================================================================================
//                                                  Java Stream Operations
//=====================================================================================================================
	
	//Let’s now see some common usages and operations we can perform on and with the help of the stream support in the language.
	
	// forEach ()
	// -----------
	// forEach() is simplest and most common operation; it loops over the stream elements, calling the supplied function on each element.
	// The method is so common that is has been introduced directly in Iterable, Map etc:
	
	@SuppressWarnings("unchecked")
	@Test
	public void whenIncrementSalaryForEachEmployee_thenApplyNewSalary() {   

		// Below statement will effectively call the salaryIncrement() on each element in the empList.
	    
		empList.stream().forEach(e -> e.salaryIncrement(10.0));	
		
		// forEach() is a terminal operation, which means that, 
		// after the operation is performed, the stream pipeline is considered consumed, 
		// and can no longer be used. We’ll talk more about terminal operations in the next section.
		
	    assertThat(empList, contains(
	      hasProperty("salary", equalTo(110000.0)),
	      hasProperty("salary", equalTo(220000.0)),
	      hasProperty("salary", equalTo(330000.0))
	    ));
	    
//	    empList.forEach(e -> System.out.println(e.getSalary()));
	}	
	
	EmployeeRepository employeeRepository=new EmployeeRepository(empList);
	// map()
	//------
	// map() produces a new stream after applying a function to each element of the original stream. The new stream could be of different type.
	
	// The following example converts the stream of Integers into the stream of Employees:
	@Test
	public void whenMapIdToEmployees_thenGetEmployeeStream() {
	    Integer[] empIds = { 1, 2, 3 };
	    
	    List<Employee> employees = Stream.of(empIds).map(employeeRepository::findById).collect(Collectors.toList());	
	    printEmployees(employees);
	    assertEquals(employees.size(), empIds.length);
	    
	    //Here, we obtain an Integer stream of employee ids from an array. 
	    //Each Integer is passed to the function employeeRepository::findById() – which returns the corresponding Employee object; 
	    //this effectively forms an Employee stream.
	}
	
	//collect()
	//----------
	// We saw how collect() works in the previous example; its one of the common ways to 
	//get stuff out of the stream once we are done with all the processing:
	@Test
	public void whenCollectStreamToList_thenGetList() {
		List<Employee> employees = empList.stream().collect(Collectors.toList());
	    
	    assertEquals(empList, employees);
	    printEmployees(employees);
	    //collect() performs mutable fold operations (repackaging elements to some data structures and applying some additional logic, 
	    //concatenating them, etc.) on data elements held in the Stream instance.
	    
	    //The strategy for this operation is provided via the Collector interface implementation. In the example above, 
	    //we used the toList collector to collect all Stream elements into a List instance.
	}
	
	
	public void printEmployees(List<Employee> employees) {
		employees.forEach(e -> System.out.println(e.toString()));
		System.out.println("-------------------------------------------------------");
	}
	
	//filter()
	//--------
	//filter(); this produces a new stream that contains elements of the original stream that pass a given test (specified by a Predicate)
	
	@Test
	public void whenFilterEmployees_thenGetFilteredStream() {
	    Integer[] empIds = { 1, 2, 3, 4 };
	    
	    List<Employee> employees = Stream.of(empIds)
	      .map(employeeRepository::findById)
	      .filter(e -> e != null)
	      .filter(e -> e.getSalary() > 200000)
	      .collect(Collectors.toList());
	    
	    printEmployees(employees);
	    assertEquals(Arrays.asList(arrayOfEmps[2]), employees);
	    //In the example above, we first filter out null references for invalid employee id's and then 
	    //again apply a filter to only keep employees with salaries over a certain threshold.
	}
	
	//findFirst()
	//-----------
	//findFirst() returns an Optional for the first entry in the stream; the Optional can, of course, be empty:
	
	@Test
	public void whenFindFirst_thenGetFirstEmployeeInStream() {
	    Integer[] empIds = { 1, 2, 3, 4 };
	    
	    Employee employee = Stream.of(empIds)
	      .map(employeeRepository::findById)
	      .filter(e -> e != null)
	      .filter(e -> e.getSalary() > 100000)
	      .findFirst()
	      .orElse(null);
	    
	    printEmployees(Arrays.asList(employee));
	    assertEquals(employee.getSalary(), new Double(200000));
	    
	    //Here, the first employee with the salary greater than 100000 is returned. If no such employee exists, then null is returned.
	}
	
	
	//toArray()
	//----------
	//We saw how we used collect() to get data out of the stream. If we need to get an array out of the stream, we can simply use toArray():
	@Test
	public void whenStreamToArray_thenGetArray() {
	    Employee[] employees = empList.stream().toArray(Employee[]::new);
	    printEmployees(Arrays.asList(employees));
	    assertThat(empList.toArray(), equalTo(employees));
	}	
	//The syntax Employee[]::new creates an empty array of Employee – which is then filled with elements from the stream.

	//flatMap()
	//----------
	//A stream can hold complex data structures like Stream<List<String>>. In cases like this, flatMap() helps us to flatten the data structure to simplify further operations:
	@Test
	public void whenFlatMapEmployeeNames_thenGetNameStream() {
	    List<List<String>> namesNested = Arrays.asList( 
	      Arrays.asList("Jeff", "Bezos"), 
	      Arrays.asList("Bill", "Gates"), 
	      Arrays.asList("Mark", "Zuckerberg"));

	    List<String> namesFlatStream = namesNested.stream()
	      .flatMap(Collection::stream)
	      .collect(Collectors.toList());
	    
	    namesFlatStream.forEach(e -> System.out.println(e.toString()));
	    
	    assertEquals(namesFlatStream.size(), namesNested.size() * 2);
	}
	
	/*@Test
	public void whenFlatMapEmployeeNames_thenGetNameStream() {
	    List<List<String>> namesNested = Arrays.asList( 
	      Arrays.asList("Jeff", "Bezos"), 
	      Arrays.asList("Bill", "Gates"), 
	      Arrays.asList("Mark", "Zuckerberg"));
	    
	    Employee[] arrayOfEmps = {
			    new Employee(1, "Jeff Bezos", 100000.0), 
			    new Employee(2, "Bill Gates", 200000.0), 
			    new Employee(3, "Mark Zuckerberg", 300000.0)
		};
	    
	    arrayOfEmps[0].setPhoneNumbers(Arrays.asList("1111111111","2222222222","3333333333"));
	    arrayOfEmps[0].setPhoneNumbers(Arrays.asList("1111111111","2222222222","3333333333"));
	    arrayOfEmps[0].setPhoneNumbers(Arrays.asList("1111111111","2222222222","3333333333"));
	    arrayOfEmps[0].setPhoneNumbers(Arrays.asList("1111111111","2222222222","3333333333"));

	    List<String> namesFlatStream = namesNested.stream()
	      .flatMap(Collection::stream)
	      .collect(Collectors.toList());
	    
	    namesFlatStream.forEach(e -> System.out.println(e.toString()));
	    
	    assertEquals(namesFlatStream.size(), namesNested.size() * 2);
	}
	*/
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
